

from Cancion import Cancion


class ListaCanciones:

    def __init__(self):
        self.Inicio = None

    def vacia(self):
        return self.Inicio == None

    def InsertarFinal(self, Nombre, Path):
        nuevo = Cancion(Nombre, Path)
        if self.vacia():
            self.Inicio = nuevo
            self.Inicio.Siguiente = self.Inicio
            self.Inicio.Anterior = self.Inicio
        else:
            aux = self.Inicio
            while aux.Siguiente != self.Inicio:
                aux = aux.Siguiente
            aux.Siguiente = nuevo
            nuevo.Anterior = aux
            nuevo.Siguiente = self.Inicio
            self.Inicio.Anterior = nuevo

    # aqui deberia de ir el metodo mostrar pero no estoy seguro si agregarlo
    # posiblemente lo agregie mas tarde
