from Album import Album


class ABB:
    """docstring for ABB"""

    def __init__(self):
        self.raiz = None

    def insertar(self, nombre, listaCanciones):
        if self.raiz == None:
            self.raiz = Album(nombre,listaCanciones)
        else:
            self.raiz.insertar(nombre, listaCanciones)

    def graficar(self):
        return self.raiz.getCodigoGraphviz()

    def inorden(self):
        print u"Recorrido inorden del arbol binario de busqueda"
        self.inordenAux(self.raiz)
        print "\n"

    def inordenAux(self, a):
        if a == None:
            return
        self.inordenAux(a.izquierdo)
        print a.nombre + ","
        self.inordenAux(a.derecho)
